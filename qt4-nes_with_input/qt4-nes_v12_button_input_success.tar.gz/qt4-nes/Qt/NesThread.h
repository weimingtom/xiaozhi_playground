#ifndef NESTHREAD_H
#define NESTHREAD_H

#include <QObject>
#include <QThread>

class NesThread : public QThread
{
    Q_OBJECT
public:
    NesThread(QObject *parent=0);
    static void delay(int i);
signals:
    void loadFrame();
protected:
    void run();

};

#endif // NESTHREAD_H
