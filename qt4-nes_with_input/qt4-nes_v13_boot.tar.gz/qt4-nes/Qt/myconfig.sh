#!/bin/sh

/opt/qt/bin/qmake Qt.pro

