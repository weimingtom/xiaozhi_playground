C
^

Simple Buttons 
""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_btn/lv_ex_btn_1.*
  :alt: Simple Button example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_btn/lv_ex_btn_1.c
      :language: c

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_btn/lv_ex_btn_2.*
  :alt: Button styling

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_btn/lv_ex_btn_2.c
      :language: c


MicroPython
^^^^^^^^^^^

No examples yet.
