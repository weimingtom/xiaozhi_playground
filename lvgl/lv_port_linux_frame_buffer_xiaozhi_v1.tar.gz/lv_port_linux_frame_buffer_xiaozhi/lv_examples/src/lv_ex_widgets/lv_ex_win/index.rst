C
^

Simple window 
"""""""""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_win/lv_ex_win_1.*
  :alt: Window example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_win/lv_ex_win_1.c
      :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
