C
^

Line Chart 
""""""""""
.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_chart/lv_ex_chart_1.png
  :alt: Simple Chart example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_chart/lv_ex_chart_1.c
      :language: c
      
      
.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_chart/lv_ex_chart_2.png
  :alt: Add a faded area effect to the line chart

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_chart/lv_ex_chart_2.c
      :language: c


MicroPython
^^^^^^^^^^^

No examples yet.
